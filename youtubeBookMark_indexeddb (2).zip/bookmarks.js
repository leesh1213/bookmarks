// bookmarks-grouped.js - grouped by video title from indexedDB
function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

let bookmarksData = [];

// YouTube 탭 찾기 및 이동 (chrome.tabs API 사용)
function navigateToYouTube(videoId, time) {
  const targetUrl = `https://www.youtube.com/watch?v=${videoId}&t=${time}s`;
  
  if (typeof chrome !== 'undefined' && chrome.tabs) {
    
    // 모든 탭 검색
    chrome.tabs.query({}, (tabs) => {
      let targetTab = null;
      
      // YouTube 탭 찾기 (같은 비디오 또는 YouTube 메인)
      for (const tab of tabs) {
        if (tab.url && tab.url.includes(`youtube.com/watch?v=${videoId}`)) {
          targetTab = tab;
          break;
        } 
      }
      
      if (targetTab) {

        // 기존 탭 활성화 후 시킹 메시지 전송
        chrome.tabs.update(targetTab.id, { active: true });
        chrome.tabs.sendMessage(targetTab.id, {
          type: 'navigateToBookmark',
          time: time
        });

        // 해당 탭의 창을 활성화
        chrome.windows.update(targetTab.windowId, { focused: true });
      } else {
        // 새 탭 생성
        chrome.tabs.create({ url: targetUrl });
      }
    });
  } else {
    // Chrome extension이 아닌 환경에서는 새 탭으로 열기
    window.open(targetUrl, '_blank');
  }
}

function renderBookmarks() {
  const container = document.getElementById('bookmarkContainer');
  container.innerHTML = '';

  // videoId별로 그룹핑 (indexedDB에서 가져온 데이터 사용)
  const groupedBookmarks = {};
  
  bookmarksData
    .sort((a,b)=> (b.addedAt||0)-(a.addedAt||0))
    .forEach(bm => {
      const videoId = bm.videoId;
      if (!groupedBookmarks[videoId]) {
        // indexedDB에 저장된 비디오 제목 또는 videoTitle 필드 사용
        const title = bm.videoTitle || bm.title || `YouTube Video ${videoId}`;
        groupedBookmarks[videoId] = {
          videoId: videoId,
          title: title,
          bookmarks: [],
          tags: bm.tags || []
        };
      }
      groupedBookmarks[videoId].bookmarks.push(bm);
    });

  // 각 비디오 그룹별로 렌더링
  Object.values(groupedBookmarks).forEach(group => {
    const videoGroup = document.createElement('div');
    videoGroup.className = 'video-group';

    // 비디오 제목 헤더
    const header = document.createElement('div');
    header.className = 'video-header';
    
    // 제목 링크
    const titleLink = document.createElement('a');
    titleLink.href = `https://www.youtube.com/watch?v=${group.videoId}`;
    titleLink.className = 'video-title';
    titleLink.textContent = group.title;
    titleLink.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      navigateToYouTube(group.videoId, 0);
    };

    header.appendChild(titleLink);

    
    // 제목 옆 태그 입력
    const tagsInput = document.createElement('input');
    tagsInput.type = 'text';
    tagsInput.placeholder = '태그 입력 (쉼표 구분)';
    tagsInput.className = 'tags-input';

    // 기존 저장된 태그 불러오기 (비디오 단위)
    tagsInput.value = group.tags ? group.tags.join(', ') : '';

    tagsInput.addEventListener('change', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.runtime.sendMessage({
          action: 'updateBookmark',
          id: group.bookmarks[0].id, // 같은 videoId 공유하므로 대표 북마크 하나 id 사용
          patch: { tags: tagsInput.value.split(',').map(t => t.trim()).filter(Boolean) }
        });
      }
    });

    // header에 추가
    header.appendChild(tagsInput);
    

    const toggleIcon = document.createElement('span');
    toggleIcon.className = 'toggle-icon';
    toggleIcon.textContent = '▼';   
    header.appendChild(toggleIcon);
    
    // 콘텐츠 컨테이너
    const content = document.createElement('div');
    content.className = 'video-content';

    // 북마크 테이블
    const table = document.createElement('table');
    
    // 테이블 헤더
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    ['색', '추가시간', '시간', '메모', '자막', '삭제'].forEach(text => {
      const th = document.createElement('th');
      th.textContent = text;
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);












    // 테이블 바디
    const tbody = document.createElement('tbody');
    
    group.bookmarks.forEach(bm => {
      const tr = document.createElement('tr');

      // 색상
      const colorTd = document.createElement('td');
      const colorDot = document.createElement('div');
      colorDot.className = 'color-dot';
      colorDot.style.background = bm.color || '#ffd54f';
      colorTd.appendChild(colorDot);

      // 추가시간
      const addedTd = document.createElement('td');
      addedTd.textContent = new Date(bm.addedAt||Date.now()).toLocaleString('ko-KR');

      // 시간 (기존 탭 찾아서 이동)
      const timeTd = document.createElement('td');
      const timeLink = document.createElement('a');
      timeLink.href = `https://www.youtube.com/watch?v=${bm.videoId}&t=${bm.time}s`;
      timeLink.className = 'time-link';
      timeLink.textContent = bm.timeLabel || formatTime(bm.time||0);
      
      timeLink.onclick = (e) => {
        e.preventDefault();
        navigateToYouTube(bm.videoId, bm.time || 0);
      };
      
      timeTd.appendChild(timeLink);

      // 메모
      const noteTd = document.createElement('td');
      const noteInput = document.createElement('input');
      noteInput.type = 'text';
      noteInput.className = 'note-input';
      noteInput.value = bm.note || '';
      noteInput.addEventListener('change', () => {
        if (typeof chrome !== 'undefined' && chrome.runtime) {
          chrome.runtime.sendMessage({ 
            action: 'updateBookmark', 
            id: bm.id, 
            patch: { note: noteInput.value } 
          });
        }
      });
      noteTd.appendChild(noteInput);

      // 자막
      const subsTd = document.createElement('td');
      subsTd.textContent = bm.subtitle || '';

      // 삭제
      const delTd = document.createElement('td');
      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'delete-btn';
      deleteBtn.textContent = '삭제';
      deleteBtn.addEventListener('click', () => {
        if (typeof chrome !== 'undefined' && chrome.runtime) {
          chrome.runtime.sendMessage({ 
            action: 'deleteBookmark', 
            id: bm.id 
          }, refresh);
        }
      });
      delTd.appendChild(deleteBtn);

      tr.appendChild(colorTd);
      tr.appendChild(addedTd);
      tr.appendChild(timeTd);
      tr.appendChild(noteTd);
      tr.appendChild(subsTd);
      tr.appendChild(delTd);

      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    content.appendChild(table);
    
    // 토글 기능
    header.addEventListener('click', (e) => {
      // 제목 링크 클릭이 아닌 경우에만 토글
      if (e.target === header || e.target === toggleIcon) {
        const isCollapsed = content.classList.contains('collapsed');
        content.classList.toggle('collapsed');
        toggleIcon.classList.toggle('collapsed');
      }
    });

    videoGroup.appendChild(header);
    videoGroup.appendChild(content);
    container.appendChild(videoGroup);
  });
}

function refresh() {
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.sendMessage({ action: 'getAllBookmarks' }, (res) => {
      console.log('Bookmarks response:', res);
      bookmarksData = (res && res.ok && res.data) ? res.data : [];
      renderBookmarks();
    });
  } else {
    // 테스트용 데이터 (실제 YouTube 제목 포함)
    bookmarksData = [
      {
        id: '1',
        videoId: 'dQw4w9WgXcQ',
        videoTitle: 'Rick Astley - Never Gonna Give You Up (Official Video)',
        time: 43,
        timeLabel: '0:43',
        note: '테스트 메모',
        subtitle: '테스트 자막',
        color: '#ff5722',
        addedAt: Date.now() - 3600000
      },
      {
        id: '2',
        videoId: 'dQw4w9WgXcQ',
        videoTitle: 'Rick Astley - Never Gonna Give You Up (Official Video)',
        time: 120,
        timeLabel: '2:00',
        note: '다른 메모',
        subtitle: '다른 자막',
        color: '#2196f3',
        addedAt: Date.now() - 1800000
      },
      {
        id: '3',
        videoId: 'jNQXAC9IVRw',
        videoTitle: 'Me at the zoo',
        time: 60,
        timeLabel: '1:00',
        note: '세번째 메모',
        subtitle: '세번째 자막',
        color: '#4caf50',
        addedAt: Date.now() - 900000
      }
    ];
    renderBookmarks();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  refresh();
});



