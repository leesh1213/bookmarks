// content.js - capture YouTube bookmarks and send to background (IndexedDB lives in background)
(function () {
  // Helpers
  function formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  function getVideoId() {
    const url = new URL(location.href);
    return url.searchParams.get('v');
  }

  function getCurrentTime() {
    const video = document.querySelector('video');
    return video ? Math.floor(video.currentTime) : 0;
  }

  function getVisibleSubtitle() {
    // Try Language Reactor (#lln-subs / .lln-sentence-wrap)
    const lln = document.querySelector('.lln-sentence-wrap, #lln-subs');
    if (lln && lln.innerText) return lln.innerText.trim();
    // Try YouTube's native captions (live text)
    const yts = document.querySelector('.ytp-caption-segment');
    if (yts && yts.innerText) return yts.innerText.trim();
    return '';
  }

  function addBookmark(color = 'yellow', note = '') {
    const videoId = getVideoId();
    if (!videoId) return;
    const time = getCurrentTime();
    const subtitle = getVisibleSubtitle();
    const title = document.title || ''; // 유튜브 제목 추가
    const data = {
      videoId,
      title,
      time,
      timeLabel: formatTime(time),
      note,
      color,
      subtitle,
      addedAt: Date.now()
    };
    chrome.runtime.sendMessage({ action: 'addBookmark', data }, (res) => {
      if (res?.ok) {
        console.log('Bookmark added:', data);
        const toast = document.createElement('div');
        toast.className = 'bookmark-toast';
        const video = document.querySelector('video');
        let top = '10%';
        let left = '50%';
        if (video) {
          const rect = video.getBoundingClientRect();
          top = rect.top + rect.height * 0.2 + 'px'; // 영상 위에서 20% 떨어진 위치
          left = rect.left + rect.width / 2 + 'px'; // 영상 중앙
        }
        // Original toast styling remains unchanged
        toast.style.cssText = `
          position: fixed;
          top: ${top};
          left: ${left};
          transform: translateX(-50%);
          padding: 10px 20px;
          background-color: ${color};
          color: black;
          border-radius: 5px;
          z-index: 10000;
          opacity: 1;
          transition: opacity 0.5s ease-in-out;
        `;
        toast.innerText = `✅ 북마크 추가됨: ${data.timeLabel}`;
        document.body.appendChild(toast);
        setTimeout(() => {
          toast.style.opacity = '0';
          setTimeout(() => toast.remove(), 500);
        }, 3000);
        // 북마크가 추가된 후 마커를 업데이트합니다.
        addBookmarkMarkers();
      } else {
        console.error('Failed to add bookmark:', res);
      }
    });
  }

  // 북마크 마커를 타임라인에 추가하는 함수
  function addBookmarkMarkers() {
    const videoId = getVideoId();
    if (!videoId) return;

    // 기존 마커를 모두 제거합니다.
    document.querySelectorAll('.yt-bookmark-marker').forEach(el => el.remove());

    // 백그라운드 스크립트로부터 현재 비디오의 북마크 목록을 요청합니다.
    chrome.runtime.sendMessage({ action: 'getAllBookmarks', videoId }, (res) => {
      if (res?.data && res.data.length > 0) {
        const video = document.querySelector('video');
        if (!video) return;

        const timeline = document.querySelector('.ytp-progress-bar');
        const duration = video.duration;

        if (timeline && duration) {
          res.data.forEach(bookmark => {
            const marker = document.createElement('div');
            const timePercent = (bookmark.time / duration) * 100;
            marker.className = 'yt-bookmark-marker';
            
            // 마커 스타일을 삼각형 모양으로 변경하고 타임라인 아래에 위치시킵니다.
            marker.style.cssText = `
              position: absolute;
              left: ${timePercent}%;
              top: 100%; /* 타임라인 아래에 위치 */
              width: 0;
              height: 0;
              border-left: 10px solid transparent; /* 좌측 경계선 */
              border-right: 10px solid transparent; /* 우측 경계선 */
              border-bottom: 20px solid ${bookmark.color}; /* 상단 경계선 (삼각형 모양) */
              z-index: 9999;
              transform: translateX(-50%); /* 정확한 위치 조정을 위해 중앙 정렬 */
              cursor: pointer; /* 클릭 가능한 모양으로 변경 */
            `;

            // 북마크로 이동하는 이벤트 리스너를 추가합니다.
            marker.addEventListener('click', () => {
              const video = document.querySelector('video');
              if (video) {
                video.currentTime = bookmark.time;
                video.play();
              }
            });

            timeline.appendChild(marker);
          });
        }
      }
    });
  }

  // Key bindings: v (yellow), b (blue), n (purple)
  document.addEventListener('keydown', (e) => {
    if (['INPUT','TEXTAREA'].includes((e.target.tagName||'').toUpperCase())) return;
    if (e.key === 'v') addBookmark('yellow');
    else if (e.key === 'b') addBookmark('blue');
    else if (e.key === 'n') addBookmark('purple');
  });

  // 페이지가 업데이트될 때마다 마커를 추가합니다.
  window.addEventListener('yt-page-data-updated', () => {
    setTimeout(addBookmarkMarkers, 1000); // 플레이어가 로드될 시간을 줍니다.
  });

  // 초기 로드 시 마커를 추가합니다.
  addBookmarkMarkers();

})();



// `bookmarks.js`에서 보내는 메시지를 수신하는 리스너
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'navigateToBookmark') {
    const time = message.time;
    // 비디오가 로드될 때까지 기다리는 함수
    const waitForVideo = (t) => {
      const video = document.querySelector('video');
      if (video) {
        video.currentTime = t;
        video.play();
      } else {
        // 비디오를 찾지 못하면 500ms 후 다시 시도
        setTimeout(() => waitForVideo(t), 500);
      }
    };
    waitForVideo(time);
    sendResponse({ status: 'success' });
  }
});