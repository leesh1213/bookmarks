// background.js (IndexedDB + message router)
const DB_NAME = 'youtubeBookmarksDB';
const DB_VERSION = 1;
const STORE = 'bookmarks';

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
        store.createIndex('videoId', 'videoId', { unique: false });
        store.createIndex('time', 'time', { unique: false });
        store.createIndex('addedAt', 'addedAt', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function dbAdd(data) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).add(data);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function dbGetAll() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const req = tx.objectStore(STORE).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function dbUpdate(id, patch) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    const getReq = store.get(id);
    getReq.onsuccess = () => {
      const val = getReq.result;
      if (!val) { resolve(false); return; }
      const updated = { ...val, ...patch };
      store.put(updated);
    };
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function dbDelete(id) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function dbClear() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).clear();
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

async function dbBulkImport(items) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    (items || []).forEach(it => {
      // remove any incoming id to avoid collision
      const { id, ...rest } = it || {};
      store.add({ ...rest });
    });
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  console.log('백그라운드 메시지 수신:', msg);
  (async () => {
    try {
      switch (msg?.action) {
        case 'addBookmark':
          console.log('Adding bookmark111:', msg.data);

          await dbAdd(msg.data);
          sendResponse({ ok: true });
          break;
        case 'getAllBookmarks':
          const all = await dbGetAll();
          sendResponse({ ok: true, data: all });
          break;
        case 'updateBookmark':
          await dbUpdate(msg.id, msg.patch || {});
          sendResponse({ ok: true });
          break;
        case 'deleteBookmark':
          await dbDelete(msg.id);
          sendResponse({ ok: true });
          break;
        case 'clearBookmarks':
          await dbClear();
          sendResponse({ ok: true });
          break;
        case 'importBookmarks':
          await dbBulkImport(msg.items || []);
          sendResponse({ ok: true });
          break;
        default:
          sendResponse({ ok: false, error: 'unknown_action' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: String(e) });
    }
  })();
  return true; // async
});
