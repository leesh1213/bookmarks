// bookmarks.js - full table with edit/delete via background
function formatTime(seconds) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

let bookmarksData = [];

function renderTable() {
  const tbody = document.querySelector('#bookmarkTable tbody');
  tbody.innerHTML = '';

  bookmarksData
    .sort((a,b)=> (b.addedAt||0)-(a.addedAt||0))
    .forEach(bm => {
      const tr = document.createElement('tr');

      const colorTd = document.createElement('td');
      const colorDot = document.createElement('div');
      colorDot.style.width = '16px';
      colorDot.style.height = '16px';
      colorDot.style.borderRadius = '50%';
      colorDot.style.background = bm.color || '#ffd54f';
      colorTd.appendChild(colorDot);

      const addedTd = document.createElement('td');
      addedTd.textContent = new Date(bm.addedAt||Date.now()).toLocaleString();

      const timeTd = document.createElement('td');
      const a = document.createElement('a');
      a.href = `https://www.youtube.com/watch?v=${bm.videoId}&t=${bm.time}s`;
      a.target = '_blank';
      a.textContent = `${bm.videoId} @ ${bm.timeLabel || formatTime(bm.time||0)}`;
      timeTd.appendChild(a);

      const noteTd = document.createElement('td');
      const note = document.createElement('input');
      note.type = 'text';
      note.value = bm.note || '';
      note.addEventListener('change', () => {
        chrome.runtime.sendMessage({ action: 'updateBookmark', id: bm.id, patch: { note: note.value } });
      });
      noteTd.appendChild(note);

      const subsTd = document.createElement('td');
      subsTd.textContent = bm.subtitle || '';

      const delTd = document.createElement('td');
      const btn = document.createElement('button');
      btn.textContent = '삭제';
      btn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'deleteBookmark', id: bm.id }, refresh);
      });
      delTd.appendChild(btn);

      tr.appendChild(colorTd);
      tr.appendChild(addedTd);
      tr.appendChild(timeTd);
      tr.appendChild(noteTd);
      tr.appendChild(subsTd);
      tr.appendChild(delTd);

      tbody.appendChild(tr);
    });
}

function refresh() {
  chrome.runtime.sendMessage({ action: 'getAllBookmarks' }, (res) => {
    bookmarksData = (res && res.ok && res.data) ? res.data : [];
    renderTable();
  });
}

document.addEventListener('DOMContentLoaded', () => {
  refresh();
});
