// content.js - capture YouTube bookmarks and send to background (IndexedDB lives in background)
(function () {
  // Helpers
  function formatTime(seconds) {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  }

  function getVideoId() {
    const url = new URL(location.href);
    return url.searchParams.get('v');
  }

  function getCurrentTime() {
    const video = document.querySelector('video');
    return video ? Math.floor(video.currentTime) : 0;
  }

  function getVisibleSubtitle() {
    // Try Language Reactor (#lln-subs / .lln-sentence-wrap)
    const lln = document.querySelector('.lln-sentence-wrap, #lln-subs');
    if (lln && lln.innerText) return lln.innerText.trim();
    // Try YouTube's native captions (live text)
    const yts = document.querySelector('.ytp-caption-segment');
    if (yts && yts.innerText) return yts.innerText.trim();
    return '';
  }

  function addBookmark(color='yellow', note='') {
    const videoId = getVideoId();
    if (!videoId) return;
    const time = getCurrentTime();
    const subtitle = getVisibleSubtitle();
    const data = {
      videoId,
      time,
      timeLabel: formatTime(time),
      note,
      color,
      subtitle,
      addedAt: Date.now()
    };
    chrome.runtime.sendMessage({ action: 'addBookmark', data }, (res) => {
      if (res?.ok) {
        console.log('Bookmark added:', data);
        // Optionally show a toast or notification
        const toast = document.createElement('div');
        toast.className = 'bookmark-toast';
        toast.style.backgroundColor = color;
        toast.innerText = `Bookmark added at ${data.timeLabel}`;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 3000); // Remove after 3 seconds
      } else {
        console.error('Failed to add bookmark:', res);
      }
      
      // optionally show toast
    });
  }

  // Key bindings: v (yellow), b (blue), n (purple)
  document.addEventListener('keydown', (e) => {
    if (['INPUT','TEXTAREA'].includes((e.target.tagName||'').toUpperCase())) return;
    if (e.key === 'v') addBookmark('yellow');
    else if (e.key === 'b') addBookmark('blue');
    else if (e.key === 'n') addBookmark('purple');
  });

})();